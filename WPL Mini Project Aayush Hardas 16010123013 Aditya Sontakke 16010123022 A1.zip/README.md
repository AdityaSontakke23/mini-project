# mini-project

Title : **ClimateSync**

-> To run this project : 
  1) git clone it
  2) install the clone on your pc in xampp folder in htdocs.
  3) make sure you have mamp/xampp as its hosted on localhost .
  4) upload the .sql file in a database in mamp/xampp .
  5) open localhost , go in htdocs select miniproject 
  6) run the homepage.php file.
